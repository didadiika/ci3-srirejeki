<?php
defined('BASEPATH') OR exit('No direct script access allowed');
include_once (dirname(__FILE__) . "/BaseController.php");

class Invoice extends BaseController{

	function __construct(){
		parent::__construct();

		$cek_login = $this->session->userdata('authenticated');
        if ($cek_login != true) {
			redirect( base_url('login') );
        }

	}

	
	function index(){
        
        
        
        #Mengambil data toko di tabel suplier dan memasukkan ke variabel data#

		#Menampilkan halaman suplier dan mem passing variabel data#
        $level = $this->session->level;
        $data['kategori'] = $this->db->order_by('id', 'ASC')->get('kategori')->result(); #Urutan tab: Ketan, IR, Katul
        if($level == "Programmer")
        {
            $this->load->view("programmer/template/header.php");
            $this->load->view("programmer/template/menu.php");

        } else if($level == "Owner"){
            $this->load->view("owner/template/header.php");
            $this->load->view("owner/template/menu.php");
        } else if($level == "Admin"){
            $this->load->view("admin/template/header.php");
            $this->load->view("admin/template/menu.php");
        }
        $this->load->view("admin/transaksi/invoice.php", $data);
        $this->load->view("admin/template/footer.php");
        #Menampilkan halaman suplier dan mem passing variabel data#
    }
    
    /* Datatables tab Ketan */
    function tampil(){
		$this->_tampil_standar("invoice_model");
	}

    /* Datatables tab Katul (sama persis dengan Ketan) */
    function tampil_katul(){
		$this->_tampil_standar("Invoice_katul_model");
	}

    /**
     * Isi datatables untuk kategori standar (Ketan, Katul).
     * Kolom & menu aksi identik; hanya model (filter kategori) yang berbeda.
     */
    private function _tampil_standar($model){
		#Mengambil data secara serverside#
		$this->load->model($model, "dt_model");
		$d = $this->dt_model->make_datatables();
		$data = array();
		$start = isset($_GET["start"]) ? $_GET["start"] : 0;
		$no = $start + 1;
		foreach($d as $r){
		    /* Ambil akumulasi pembayaran */
            $bayar = 0;
            $by = $this->db->query("select sum(bayar) as bayar from invoice_bayar where id_invoice='$r->id_invoice' and deleted_at is null");
            if($by->num_rows() > 0){
                foreach($by->result() as $b){
                    $bayar = $b->bayar;
                }
            }
            /* -------------------------------------------------- */

			$sub_array = array();
			$sub_array[] = $no++;
            $sub_array[] = tgl_pecah($r->tanggal);
            $sub_array[] = $r->nama_pelanggan;
            $sub_array[] = $r->no_polisi;
            $sub_array[] = uang($r->harga_kbk);
            $sub_array[] = uang($r->total);
            
            if($r->status == "Proses")
            {
                $sub_array[] = '<span class="badge btn-warning">Proses</span>';
                if($r->status_bayar == "Belum Lunas"){ $sub_array[] = '<span class="badge btn-warning">Belum Lunas</span>'; } else {
                    $sub_array[] = '<span class="badge btn-success">Lunas</span>';
                }
                $sub_array[] = uang($r->total - $bayar);
                
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Tambah Barang</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                
                
            }
            else
            {
                $sub_array[] = '<span class="badge btn-primary">Selesai</span>';
                if($r->status_bayar == "Belum Lunas"){ 
                    $sub_array[] = '<span class="badge btn-warning">Belum Lunas</span>'; 
                    $sub_array[] = uang($r->total - $bayar);
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Lihat</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_bayar"
                        tanggal-invoice="'.tgl_pecah($r->tanggal).'" pelanggan="'.$r->nama_pelanggan.'" 
                        total-invoice="'.(int)$r->total.'" dibayar="'.(int)$bayar.'" sisa="'.(int)($r->total - $bayar).'"
                        >Input Pembayaran</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_riwayat">Riwayat Pembayaran</a></li>
                        <li><a href="'.base_url('transaksi/invoice/cetak-nota/'.$r->id_invoice).'" target="_blank">Cetak</a></li>
                        <li><a href="'.base_url('transaksi/invoice/surat-jalan/'.$r->id_invoice).'" target="_blank">Surat Jalan</a></li>
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                } else {
                    $sub_array[] = '<span class="badge btn-success">Lunas</span>';
                    $sub_array[] = uang($r->total - $bayar);
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Lihat</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_riwayat">Riwayat Pembayaran</a></li>
                        <li><a href="'.base_url('transaksi/invoice/cetak-nota/'.$r->id_invoice).'" target="_blank">Cetak</a></li>
                        <li><a href="'.base_url('transaksi/invoice/surat-jalan/'.$r->id_invoice).'" target="_blank">Surat Jalan</a></li>
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                    
                }
                
            }
			
			$data[] = $sub_array;
		}
		#Mengambil data kategori di tabel kategori dan memasukkan ke variabel data#
		$draw = "";
		if(isset($_POST["draw"])){$draw = $_POST["draw"];}

			$output = array(
				"draw" 				=> intval($draw),
				"recordsTotal" 		=> $this->dt_model->get_all_data(),
				"recordsFiltered" 	=> $this->dt_model->get_filtered_data(),
				"data"				=> $data
		
		);

		echo json_encode($output);
	}

    function tampil_ir(){
		#Mengambil data kain secara serverside#
		$this->load->model("Invoice_ir_model");
		$d = $this->Invoice_ir_model->make_datatables();
		$data = array();
		$start = isset($_GET["start"]) ? $_GET["start"] : 0;
		$no = $start + 1;
		foreach($d as $r){
		    /* Ambil akumulasi pembayaran */
            $bayar = 0;
            $by = $this->db->query("select sum(bayar) as bayar from invoice_bayar where id_invoice='$r->id_invoice' and deleted_at is null");
            if($by->num_rows() > 0){
                foreach($by->result() as $b){
                    $bayar = $b->bayar;
                }
            }
            /* -------------------------------------------------- */

			$sub_array = array();
			$sub_array[] = $no++;
            $sub_array[] = tgl_pecah($r->tanggal);
            $sub_array[] = $r->nama_pelanggan;
            $sub_array[] = $r->no_polisi;
            /* Kolom khusus tab IR: Tonase, Retur, Tonase Akhir (= Tonase - Retur) */
            $sub_array[] = uang($r->total_tonase);
            $sub_array[] = ((int)$r->tonase_return > 0)
                ? '<span class="text-red"><strong>'.uang($r->tonase_return).'</strong></span>'
                : '<span class="text-muted">-</span>';
            $sub_array[] = '<strong>'.uang((float)$r->total_tonase - (int)$r->tonase_return).'</strong>';

            /* Menu Retur: Tambah jika belum ada, Edit + Hapus jika sudah ada */
            $attr_retur = 'data="'.$r->id_invoice.'" tanggal-invoice="'.tgl_pecah($r->tanggal).'"
                        pelanggan="'.htmlspecialchars((string)$r->nama_pelanggan, ENT_QUOTES).'" no-truk="'.htmlspecialchars((string)$r->no_polisi, ENT_QUOTES).'"
                        total-tonase="'.(float)$r->total_tonase.'" tonase-return="'.(int)$r->tonase_return.'"';
            if((int)$r->tonase_return > 0){
                $menu_retur = '<li class="divider"></li>
                        <li><a href="javascript:void(0)" class="item_retur" '.$attr_retur.'>Edit Retur</a></li>
                        <li><a href="javascript:void(0)" class="item_hapus_retur" '.$attr_retur.'>Hapus Retur</a></li>
                        <li class="divider"></li>';
            } else {
                $menu_retur = '<li class="divider"></li>
                        <li><a href="javascript:void(0)" class="item_retur" '.$attr_retur.'>Tambah Retur</a></li>
                        <li class="divider"></li>';
            }
            
            if($r->status == "Proses")
            {
                $sub_array[] = '<span class="badge btn-warning">Proses</span>';
                $sub_array[] = uang($r->total - $bayar);
                
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Tambah Barang</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        '.$menu_retur.'
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                
                
            }
            else
            {
                $sub_array[] = '<span class="badge btn-primary">Selesai</span>';
                if($r->status_bayar == "Belum Lunas"){ 
                    $sub_array[] = uang($r->total - $bayar);
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Lihat</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_bayar"
                        tanggal-invoice="'.tgl_pecah($r->tanggal).'" pelanggan="'.$r->nama_pelanggan.'" 
                        total-invoice="'.(int)$r->total.'" dibayar="'.(int)$bayar.'" sisa="'.(int)($r->total - $bayar).'"
                        >Input Pembayaran</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_riwayat">Riwayat Pembayaran</a></li>
                        <li><a href="'.base_url('transaksi/invoice/cetak-nota/'.$r->id_invoice).'" target="_blank">Cetak</a></li>
                        <li><a href="'.base_url('transaksi/invoice/surat-jalan/'.$r->id_invoice).'" target="_blank">Surat Jalan</a></li>
                        '.$menu_retur.'
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                } else {
                    $sub_array[] = uang($r->total - $bayar);
                    $sub_array[] = '
                    <div class="btn-group">
                    <button type="button" class="btn btn-default">Pilih</button>
                    <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                        <span class="caret"></span>
                        <span class="sr-only">Toggle Dropdown</span>
                    </button>
                        <ul class="dropdown-menu" role="menu">
                        <li><a href="'.base_url('transaksi/invoice/tambah-barang/'.$r->id_invoice).'">Lihat</a></li>
                        <li><a href="'.base_url('transaksi/invoice/biaya/'.$r->id_invoice).'">Biaya Invoice</a></li>
                        <li><a href="javascript:void(0)" data="'.$r->id_invoice.'" class="item_riwayat">Riwayat Pembayaran</a></li>
                        <li><a href="'.base_url('transaksi/invoice/cetak-nota/'.$r->id_invoice).'" target="_blank">Cetak</a></li>
                        <li><a href="'.base_url('transaksi/invoice/surat-jalan/'.$r->id_invoice).'" target="_blank">Surat Jalan</a></li>
                        '.$menu_retur.'
                        <li><a href="javascript:;" class="item_hapus" data="'.$r->id_invoice.'" >Hapus</a></li>
                        </ul>
                    </div>';
                    
                }
                
            }
			
			$data[] = $sub_array;
		}
		#Mengambil data kategori di tabel kategori dan memasukkan ke variabel data#
		$draw = "";
		if(isset($_POST["draw"])){$draw = $_POST["draw"];}

			$output = array(
				"draw" 				=> intval($draw),
				"recordsTotal" 		=> $this->Invoice_ir_model->get_all_data(),
				"recordsFiltered" 	=> $this->Invoice_ir_model->get_filtered_data(),
				"data"				=> $data
		
		);

		echo json_encode($output);
	}

    function tambah_barang($id){
        

        #Menampilkan halaman suplier dan mem passing variabel data#
        $level = $this->session->level;
        if($level == "Programmer")
        {
            $this->load->view("programmer/template/header.php");
            $this->load->view("programmer/template/menu.php");

        } else if($level == "Owner"){
            $this->load->view("owner/template/header.php");
            $this->load->view("owner/template/menu.php");
        } else if($level == "Admin"){
            $this->load->view("admin/template/header.php");
            $this->load->view("admin/template/menu.php");
        }

        
        if($id)
        {
        #$id = $this->uri->segment(4);
        $this->load->model("pembelian_model");
        $data["invoice"] = $this->db->query("select * from invoice, pelanggan where invoice.id_invoice='$id' and invoice.id_pelanggan = pelanggan.id_pelanggan");
        $data["barang"] = $this->db->query("select * from invoice_d where invoice_d.id_invoice='$id' order by invoice_d.created_at asc");
        if($data["invoice"]->num_rows() > 0){
            foreach($data["invoice"]->result() as $r){
                $status = $r->status;
            }
        }
        $data["status"] = $status;
        $this->load->view("admin/transaksi/invoice-inputing.php",$data);
        }
        $this->load->view("admin/template/footer.php");
        #Menampilkan halaman suplier dan mem passing variabel data#
    }


    function buat(){
        $id_kategori     = $this->input->post('id_kategori');
        $id_pelanggan = $this->input->post("id_pelanggan");
        $tanggal = tgl_pecah($this->input->post("tanggal"));
        $no_polisi = $this->input->post("no_polisi"); 
        $harga_kbk = 0;

        #Kategori Katul memakai tarif kuli naik khusus Katul, selain itu tarif kuli naik biasa#
        $kategori = $this->db->get_where('kategori', array('id' => $id_kategori))->row();
        $is_katul = ($kategori && strtolower(trim($kategori->nama_kategori)) == 'katul');

        $kbk = $this->db->query("select * from sistem_setting ");
        if($kbk->num_rows() > 0){
            foreach($kbk->result() as $r){
                $harga_kbk = $is_katul ? $r->kuli_naik_for_katul_price : $r->kuli_naik_price;
            }
        }
        
        $id = id_primary();
        $data = array("id_invoice"=>$id,"id_kategori"=>$id_kategori,"id_pelanggan"=>$id_pelanggan,"no_polisi"=>$no_polisi,"tanggal"=>$tanggal,"harga_kbk"=>$harga_kbk,"status"=>"Proses");
        $this->load->model("invoice_model");
        $this->invoice_model->simpan_data("invoice",$data);
        
        #redirect(base_url('data/pengirim')); 
        
    }


    /**
     * Cetak faktur sebagai PDF (stream inline ke browser).
     * Route : transaksi/invoice/cetak-nota/{id_invoice}
     * Opsi  : ?download=1  -> paksa unduh file
     *         ?html=1      -> tampilkan HTML mentah (untuk cek layout)
     */
    function cetak_nota($id){

        $inv = $this->db->query("select * from invoice, pelanggan where invoice.id_pelanggan = pelanggan.id_pelanggan and
            invoice.id_invoice = ? and
            invoice.status = 'Selesai' and
            invoice.deleted_at is null", array($id))->row();

        if (!$inv) {
            show_error('Faktur tidak ditemukan atau belum berstatus Selesai.', 404, 'Faktur Tidak Ditemukan');
            return;
        }

        $items = $this->db->query("select * from invoice_d where id_invoice = ? order by created_at asc", array($id))->result();

        $rekening = $this->db->query("select * from rekening, rekening_bank
            where rekening.selected = '1' and rekening_bank.id_bank = rekening.id_bank")->result();

        $bayar = (int) $this->db->query("select coalesce(sum(bayar),0) as b from invoice_bayar
            where id_invoice = ? and deleted_at is null", array($id))->row()->b;

        // Total dihitung ulang dari detail agar selalu sinkron dengan baris barang
        $total = 0;
        foreach ($items as $m) { $total += (int) $m->sub_total; }

        // Nomor faktur: pakai kolom nomor jika ada, jika tidak buat dari tanggal + potongan ID
        $this->config->load('faktur');
        if (!empty($inv->no_invoice)) {
            $nomor = $inv->no_invoice;
        } else {
            $nomor = $this->config->item('faktur_prefix') . '-' . date('ymd', strtotime($inv->tanggal))
                   . '-' . strtoupper(substr(str_replace('-', '', $inv->id_invoice), 0, 6));
        }

        $data = array(
            'inv'      => $inv,
            'items'    => $items,
            'rekening' => $rekening,
            'total'    => $total,
            'bayar'    => $bayar,
            'sisa'     => $total - $bayar,
            'nomor'    => $nomor,
            'toko'     => $this->config->item('faktur_toko'),
            'judul'    => $this->config->item('faktur_judul'),
            'ttd'      => $this->config->item('faktur_ttd'),
            'catatan'  => $this->config->item('faktur_catatan'),
            'petugas'  => $this->session->userdata('username'),
        );

        $html = $this->load->view('admin/transaksi/invoice-cetak-pdf.php', $data, TRUE);

        if ($this->input->get('html')) {
            echo $html;
            return;
        }

        $nama_file = 'Faktur-' . $nomor . '-' . preg_replace('/[^A-Za-z0-9]+/', '_', $inv->nama_pelanggan) . '.pdf';
        $this->_stream_pdf($html, $data['judul'] . ' ' . $nomor, $data['toko']['nama'], $nama_file);
    }

    /**
     * Cetak Surat Jalan sebagai PDF (stream inline ke browser).
     * Route : transaksi/invoice/surat-jalan/{id_invoice}
     * Tanpa harga, nominal, maupun rekening pembayaran.
     * Opsi  : ?download=1  -> paksa unduh file
     *         ?html=1      -> tampilkan HTML mentah (untuk cek layout)
     */
    function surat_jalan($id){

        $inv = $this->db->query("select * from invoice, pelanggan where invoice.id_pelanggan = pelanggan.id_pelanggan and
            invoice.id_invoice = ? and
            invoice.status = 'Selesai' and
            invoice.deleted_at is null", array($id))->row();

        if (!$inv) {
            show_error('Surat jalan tidak ditemukan atau transaksi belum berstatus Selesai.', 404, 'Surat Jalan Tidak Ditemukan');
            return;
        }

        $items = $this->db->query("select * from invoice_d where id_invoice = ? order by created_at asc", array($id))->result();

        $total_qty = 0;
        foreach ($items as $m) { $total_qty += (float) $m->qty; }

        $this->config->load('faktur');
        $kode = date('ymd', strtotime($inv->tanggal)) . '-' . strtoupper(substr(str_replace('-', '', $inv->id_invoice), 0, 6));
        $no_faktur = !empty($inv->no_invoice) ? $inv->no_invoice : $this->config->item('faktur_prefix') . '-' . $kode;
        $nomor     = $this->config->item('sj_prefix') . '-' . $kode;

        $data = array(
            'inv'       => $inv,
            'items'     => $items,
            'total_qty' => $total_qty,
            'nomor'     => $nomor,
            'no_faktur' => $no_faktur,
            'toko'      => $this->config->item('faktur_toko'),
            'judul'     => $this->config->item('sj_judul'),
            'ttd'       => $this->config->item('sj_ttd'),
            'satuan'    => $this->config->item('sj_satuan'),
            'petugas'   => $this->session->userdata('username'),
        );

        $html = $this->load->view('admin/transaksi/invoice-surat-jalan-pdf.php', $data, TRUE);

        if ($this->input->get('html')) {
            echo $html;
            return;
        }

        $nama_file = 'SuratJalan-' . $nomor . '-' . preg_replace('/[^A-Za-z0-9]+/', '_', $inv->nama_pelanggan) . '.pdf';
        $this->_stream_pdf($html, $data['judul'] . ' ' . $nomor, $data['toko']['nama'], $nama_file);
    }

    /**
     * Render HTML -> PDF dengan Dompdf lalu stream ke browser.
     * Diawali underscore agar tidak bisa diakses lewat URL (aturan CI3).
     */
    private function _stream_pdf($html, $judul, $author, $nama_file){
        $options = new \Dompdf\Options();
        $options->set('isRemoteEnabled', false);
        $options->set('isHtml5ParserEnabled', true);
        $options->set('defaultFont', 'Helvetica');
        $options->set('chroot', FCPATH);

        $dompdf = new \Dompdf\Dompdf($options);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper($this->config->item('faktur_kertas'), $this->config->item('faktur_orientasi'));
        $dompdf->addInfo('Title', $judul);
        $dompdf->addInfo('Author', $author);
        $dompdf->render();

        // Nomor halaman (berguna jika barang banyak hingga > 1 halaman)
        $canvas = $dompdf->getCanvas();
        $font   = $dompdf->getFontMetrics()->getFont('Helvetica', 'normal');
        $canvas->page_text($canvas->get_width() - 110, $canvas->get_height() - 26,
            'Halaman {PAGE_NUM} dari {PAGE_COUNT}', $font, 7, array(0.3, 0.3, 0.3));

        $dompdf->stream($nama_file, array('Attachment' => (bool) $this->input->get('download')));
        exit;
    }

    function pelanggan_cari(){
        $cari = trim($this->input->get("cari"));
        $page = $this->input->get("page");#Untuk Pagination
        $batas = $this->input->get("batas");
        $offset = ($page - 1) * $batas;
        if(!empty($cari))
        {   
            $query = $this->db->query("select * from pelanggan where 
            deleted_at is null and
            nama_pelanggan like '%$cari%' order by nama_pelanggan asc
            limit $offset,$batas
            ");

            $count_filtered = $query->num_rows();
            $count_all = $this->db->query("select * from pelanggan where 
            deleted_at is null and
            nama_pelanggan like '%$cari%' order by nama_pelanggan asc
            ")->num_rows();
            
            if($query->num_rows() > 0){
            $list = array();
            foreach($query->result() as $row) {
                    $list[] = array("id"=>$row->id_pelanggan, "text"=>$row->nama_pelanggan);
                
            }
            $hasil = array("pelanggan" => $list,
            "count_filtered" => $count_all
            );
            echo json_encode($hasil);
            }
            else
            {
                echo "Tidak Ketemu";
            }
            
        }
        else
        {
            echo "Tidak Valid";
        }
    }

    function hapus(){
        $id = $this->input->post('id_hapus');       
        #Hapus tabel transaksi dan transaksi_invoice
        $p = $this->db->query("select * from transaksi_invoice where id_invoice='$id' ");
        if($p->num_rows() > 0){
            foreach($p->result() as $r){
                $this->db->query("update transaksi set deleted_at='".date("Y-m-d H:i:s")."' where id_transaksi='$r->id_transaksi' ");
            }
            $this->db->query("update transaksi_invoice set deleted_at='".date("Y-m-d H:i:s")."' where id_invoice='$id' ");
        }
        #Hapus Tabel invoice 
        $data = array("deleted_at"=>date("Y-m-d H:i:s"));
        $where = array("id_invoice"=>$id);

        $this->load->model("invoice_model");
        $this->invoice_model->update_data("invoice",$data,$where);
        

        redirect(base_url('transaksi/invoice')); 
        
    }

    function hapus_barang(){
        $id = $this->input->post('id_hapus');
        
        
        $p = $this->db->query("select * from invoice_d where id_id='$id' ");
        if($p->num_rows() > 0){

            foreach($p->result() as $r){
                $id_invoice = $r->id_invoice;
            }
            
            $this->db->query("delete from invoice_d where id_id='$id' ");

            $tot = $this->db->query("select sum(sub_total) as b, sum(qty) as q from invoice_d where id_invoice='$id_invoice' ");
            $total = 0;
            $total_tonase = 0;
            if($tot->num_rows() > 0){
                foreach($tot->result() as $t){
                    $total = $t->b;
                    $total_tonase = $t->q;
                }
                $this->db->query("update invoice set total_tonase='$total_tonase',total= '$total' where id_invoice='$id_invoice' ");
            }

        }
        

        redirect(base_url('transaksi/pembelian')); 
        
    }

    function update(){

        
    }

    function selesai(){
        $id = $this->input->post('id_selesai');
        
        $data = array("status"=>"Selesai");
        $where = array("id_invoice"=>$id);

        $this->load->model("invoice_model");
        $this->invoice_model->update_data("invoice",$data,$where);

        $p = $this->db->query("select * from invoice where id_invoice='$id' ");
        if($p->num_rows() > 0){
            foreach($p->result() as $r){
                $tanggal = $r->tanggal;
                $no_polisi = $r->no_polisi;
                $pembayaran_kuli = $r->total_tonase * $r->harga_kbk;
            }
        #-------------------------------------------------------------------#
            #Insert pengeluaran KULI ANGKUT ke tabel transaksi
            $id_transaksi = id_primary();
            $keterangan = "Pembayaran Kuli Angkut (".$no_polisi.")";
            $data = array("id_transaksi"=>$id_transaksi,
                        "nota"=>NULL,
                        "tanggal"=>$tanggal,
                        "keterangan"=>$keterangan,
                        "debit"=>0,
                        "kredit"=>$pembayaran_kuli,
                        "jenis"=>"Pengeluaran"
                    );
            $this->invoice_model->simpan_data("transaksi",$data);
            #Insert ke tabel transaksi_invoice
            $data = array("id_ti"=>id_primary(),
                        "id_invoice"=>$id,
                        "id_transaksi"=>$id_transaksi
                    );
            $this->invoice_model->simpan_data("transaksi_invoice",$data);
        }

        redirect(base_url('transaksi/invoice')); 
        
    }


    function tambah(){
        $id = id_primary();
        $id_invoice = $this->input->post("id_invoice");
        $barang = $this->input->post("barang");
        $qty = $this->input->post("qty");
        $harga = uangPecah($this->input->post("harga"));
        $sub_total = uangPecah($this->input->post("sub_total"));

        $this->db->query("insert into invoice_d (id_id, id_invoice, nama_barang, qty, harga, sub_total) 
        values ('$id','$id_invoice','$barang','$qty','$harga','$sub_total')");
        $tot = $this->db->query("select sum(sub_total) as b, sum(qty) as q from invoice_d where id_invoice='$id_invoice' ");
        $total = 0;
        $total_tonase = 0;
        if($tot->num_rows() > 0){
            foreach($tot->result() as $t){
                $total = $t->b;
                $total_tonase = $t->q;
            }
        }
        $this->db->query("update invoice set total_tonase='$total_tonase',total = '$total' where id_invoice='$id_invoice' ");
       

    }


    function list_hapus(){
        $id = $this->uri->segment(3);
        
        $where = array("id_d_beli"=>$id);

        $this->load->model("pembelian_d_model");
        $this->pembelian_d_model->hapus_data("pembelian_d",$where);
        
        
        #update total
        $id_pembelian = $this->uri->segment(4);
        $this->load->model("pembelian_model");
        $t = $this->pembelian_model->cari_total($id_pembelian);
        if($t->num_rows() > 0){
            foreach($t->result() as $h){
                $total = $h->total;
            }
        }
        else
        {
            $total = 0;
        }
        $data = array("total"=>$total);
        $where = array("id_pembelian"=>$id_pembelian);
        $this->pembelian_model->update_data("pembelian",$data,$where);

        redirect(base_url('transaksi/pembelian/input/'.$this->enkripsi_url->encode($id_pembelian))); 
        
    }

    function simpan(){
        $id = $this->input->post("id");
        $harga_kbk = $this->input->post("harga_kbk");
        
        $data = array("harga_kbk"=>$harga_kbk,"updated_at"=>date("Y-m-d H:i:s"));
        $where = array("id_invoice"=>$id);
        $this->load->model("invoice_model");
        $this->invoice_model->update_data("invoice",$data,$where);
        
        redirect(base_url('transaksi/invoice')); 

    }



    function cetak()
    {
        $id = $this->enkripsi_url->decode($this->uri->segment(4));
        $this->load->model("pembelian_model");

        $data["pembelian"] = $this->pembelian_model->tampil_data_edit($id);
        $data["keranjang"] = $this->db->query("select pembelian_d.* from pembelian_d where
        pembelian_d.id_pembelian='$id' ");
        $this->load->view("admin/transaksi/pembelian-cetak.php",$data);
    }



    function simpan_pembayaran(){
        #-----Simpan Pembayaran------#
        $this->load->model("invoice_model");
        $id_bayar = $this->input->post('id_bayar');
        $tanggal = tgl_pecah($this->input->post('tanggal'));
        $bayar = uangPecah($this->input->post('bayar'));
        $total_tagihan = uangPecah($this->input->post('total_invoice'));

            $id_ib = id_primary();
            $data = array("id_ib"=>$id_ib,
                        "id_invoice"=>$id_bayar,
                        "tanggal"=>$tanggal,
                        "bayar"=>$bayar
                    );
            $this->invoice_model->simpan_data("invoice_bayar",$data);
        #-----Simpan Pembayaran------#

        #-----Kontrol Pelunasan------#
        $total_bayar = 0;
        $t = $this->db->query("select sum(bayar) as b  from invoice_bayar where id_invoice='$id_bayar' and deleted_at is null");
        if($t->num_rows() > 0){
            foreach($t->result() as $r){
                $total_bayar = $r->b;
            }
        }
        if($total_bayar >= $total_tagihan){
            $this->db->query("update invoice set status_bayar='Lunas' where id_invoice='$id_bayar' ");
        } else {
            $this->db->query("update invoice set status_bayar='Belum Lunas' where id_invoice='$id_bayar' ");
        }
        #-----Kontrol Pelunasan-----#

    }

    function hapus_pembayaran(){
        #-----Hapus Pembayaran------#
        $this->load->model("invoice_model");
        $id_hapus = $this->input->post('id_hapus');
        $id_invoice = $this->input->post('id_invoice');

            $data = array("deleted_at"=>date("Y-m-d H:i:s")
                    );
            $where = array("id_ib"=>$id_hapus);
            $this->invoice_model->update_data("invoice_bayar",$data,$where);
        #-----Hapus Pembayaran------#

        #-----Kontrol Pelunasan------#
        $total_tagihan = 0;
        $inv = $this->db->query("select total from invoice where id_invoice='$id_invoice' ")->row();
        if($inv){ $total_tagihan = $inv->total; }

        $total_bayar = 0;
        $t = $this->db->query("select sum(bayar) as b  from invoice_bayar where id_invoice='$id_invoice' and deleted_at is null");
        if($t->num_rows() > 0){
            foreach($t->result() as $r){
                $total_bayar = $r->b;
            }
        }
        if($total_bayar >= $total_tagihan){
            $this->db->query("update invoice set status_bayar='Lunas' where id_invoice='$id_invoice' ");
        } else {
            $this->db->query("update invoice set status_bayar='Belum Lunas' where id_invoice='$id_invoice' ");
        }
        #-----Kontrol Pelunasan-----#
    }

    /* ============================== RETUR (khusus IR) ============================== */

    private function _json_retur($status, $message, $code = 200){
        $this->output
            ->set_status_header($code)
            ->set_content_type('application/json')
            ->set_output(json_encode(array('status' => $status, 'message' => $message)));
    }

    /** Ambil invoice IR yang masih aktif, NULL jika tidak ada / bukan IR */
    private function _invoice_ir($id_invoice){
        return $this->db->query("select invoice.* from invoice
            inner join kategori on kategori.id = invoice.id_kategori
            where invoice.id_invoice = ? and kategori.nama_kategori = 'IR' and invoice.deleted_at is null",
            array($id_invoice))->row();
    }

    /**
     * Tambah / Edit retur (keduanya sama: menyimpan nilai tonase_return).
     * POST : id_invoice, tonase_return
     */
    function simpan_retur(){
        $id_invoice    = $this->input->post('id_invoice');
        $tonase_return = (int) uangPecah($this->input->post('tonase_return'));

        $inv = $this->_invoice_ir($id_invoice);
        if(!$inv){
            return $this->_json_retur(false, 'Invoice IR tidak ditemukan.', 404);
        }
        if($tonase_return <= 0){
            return $this->_json_retur(false, 'Tonase retur harus lebih dari 0.');
        }
        if($tonase_return > (float) $inv->total_tonase){
            return $this->_json_retur(false, 'Tonase retur tidak boleh melebihi total tonase invoice ('.uang($inv->total_tonase).').');
        }

        $this->load->model("invoice_model");
        $this->invoice_model->update_data("invoice",
            array("tonase_return" => $tonase_return, "updated_at" => date("Y-m-d H:i:s")),
            array("id_invoice" => $id_invoice));

        return $this->_json_retur(true, 'Retur berhasil disimpan.');
    }

    /**
     * Hapus retur -> tonase_return dikembalikan ke 0.
     * POST : id_invoice
     */
    function hapus_retur(){
        $id_invoice = $this->input->post('id_invoice');

        if(!$this->_invoice_ir($id_invoice)){
            return $this->_json_retur(false, 'Invoice IR tidak ditemukan.', 404);
        }

        $this->load->model("invoice_model");
        $this->invoice_model->update_data("invoice",
            array("tonase_return" => 0, "updated_at" => date("Y-m-d H:i:s")),
            array("id_invoice" => $id_invoice));

        return $this->_json_retur(true, 'Retur berhasil dihapus.');
    }

    /* ============================ END RETUR ============================ */

	function riwayat_pembayaran($id)
    {
        $this->load->model("invoice_model");

        $data["invoice"] = $this->db->query("select * from invoice, pelanggan where invoice.id_invoice='$id' and invoice.id_pelanggan = pelanggan.id_pelanggan");
        $data["pembayaran"] = $this->db->query("select * from invoice_bayar where id_invoice='$id' order by tanggal asc, created_at asc");
        $this->load->view("admin/transaksi/invoice-history-pembayaran-tampil.php",$data);
    }
}
?>