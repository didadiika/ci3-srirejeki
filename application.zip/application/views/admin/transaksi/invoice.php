<script type="text/javascript">

  function uang(b)
  { 
  var _minus = false;
  if (b<0) _minus = true;
  b = b.toString();
  b=b.replace(".","");
  b=b.replace("-","");
  c = "";
  panjang = b.length;
  j = 0;
  for (i = panjang; i > 0; i--){
     j = j + 1;
     if (((j % 3) == 1) && (j != 1)){
       c = b.substr(i-1,1) + "." + c;
     } else {
       c = b.substr(i-1,1) + c;
     }
  }
  if (_minus) c = "-" + c ;
    
  hasil = c;
  return hasil;
  }

$(document).ready(function(){

/*--------- FIX: dropdown "Pilih" terpotong oleh area scroll DataTables (scrollX) ---------*/
/* Menu dibuat position:fixed agar keluar dari .dataTables_scrollBody yang ber-overflow */
$(document).on('shown.bs.dropdown', '.dataTables_scrollBody .btn-group', function(){
    var $menu = $(this).find('.dropdown-menu');
    var btn   = this.getBoundingClientRect();
    var mh = $menu.outerHeight(), mw = $menu.outerWidth();
    var top  = btn.bottom;
    if (top + mh > window.innerHeight && btn.top - mh > 0) { top = btn.top - mh; } // buka ke atas jika mentok bawah
    var left = btn.left;
    if (left + mw > window.innerWidth) { left = Math.max(0, btn.right - mw); }      // geser jika mentok kanan
    $menu.css({ position: 'fixed', top: top, left: left, right: 'auto', bottom: 'auto', zIndex: 1050 });
});
$(document).on('hidden.bs.dropdown', '.dataTables_scrollBody .btn-group', function(){
    $(this).find('.dropdown-menu').removeAttr('style');
});
/* Tutup dropdown yang terbuka saat halaman / tabel di-scroll agar menu tidak "melayang" salah posisi */
function tutupDropdownTabel(){
    $('.dataTables_scrollBody .btn-group.open').removeClass('open').find('.dropdown-menu').removeAttr('style');
}
$(window).on('scroll resize', tutupDropdownTabel);
document.addEventListener('scroll', function(e){
    if ($(e.target).hasClass('dataTables_scrollBody')) { tutupDropdownTabel(); }
}, true);
/*------------------------------------------------------------------------------------------*/
$('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
    $.fn.dataTable.tables({ visible: true, api: true }).columns.adjust();
});

  var table_ketan = $('#tabel-ketan').DataTable({
     "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json"
        },
        "processing": true,
        "serverSide": true,
        autoWidth: false,
        scrollX: true,
        "order": [],
        "ajax": {
              url:"<?php echo base_url('invoice/tampil');?>",
              type:"GET",
        },
        "columnDefs": [ {
            "targets": 0,
            "orderable":false,
            "searchable":false
        },
        {
            "targets": 8,
            "orderable":false,
            "searchable":false
        },
        {
              "targets": 9,
              "orderable":false,
              "searchable":false
        }],

    });

  var table_katul = $('#tabel-katul').DataTable({
     "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json"
        },
        "processing": true,
        "serverSide": true,
        autoWidth: false,
        scrollX: true,
        "order": [],
        "ajax": {
              url:"<?php echo base_url('invoice/tampil_katul');?>",
              type:"GET",
        },
        "columnDefs": [ {
            "targets": 0,
            "orderable":false,
            "searchable":false
        },
        {
            "targets": 8,
            "orderable":false,
            "searchable":false
        },
        {
              "targets": 9,
              "orderable":false,
              "searchable":false
        }],

    });

  var table_ir = $('#tabel-ir').DataTable({
     "language": {
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Indonesian.json"
        },
        "processing": true,
        "serverSide": true,
        autoWidth: false,
        scrollX: true,
        "order": [],
        "ajax": {
              url:"<?php echo base_url('invoice/tampil_ir');?>",
              type:"GET",
        },
        "columnDefs": [ {
            "targets": 0,
            "orderable":false,
            "searchable":false
        },
        {
            "targets": 8,
            "orderable":false,
            "searchable":false
        },
        {
              "targets": 9,
              "orderable":false,
              "searchable":false
        }],

    });

//Buat Invoice
$("#form-buat").submit(function(e) {
e.preventDefault(); // avoid to execute the actual submit of the form.
var form = $(this);
var actionUrl = form.attr('action');
var method = form.attr('method');
$.ajax({
    type: method,
    url: actionUrl,
    data: form.serialize(), // serializes the form's elements.
    success: function(data)
    {
      console.log('Submit Berhasil !');
      table_ketan.ajax.reload();
      table_ir.ajax.reload();
      table_katul.ajax.reload();
    },
    error: function (data) {
      console.log('Submit Error !');
    },
});
$("#form-buat")[0].reset();
$("#modal-buat").modal('hide');

});


//GET HAPUS
$('#tabel-ketan, #tabel-katul').on('click','.item_hapus',function(){
            var id=$(this).attr('data');
            var nama=$(this).attr('nama');
            $('#ModalHapus').modal('show');
            $('[name="id_hapus"]').val(id);
            $('#nama').html(nama);
        });

$('#tabel-ir').on('click','.item_hapus',function(){
            var id=$(this).attr('data');
            var nama=$(this).attr('nama');
            $('#ModalHapus').modal('show');
            $('[name="id_hapus"]').val(id);
            $('#nama').html(nama);
        });

$('#tabel-ketan, #tabel-katul').on('click','.item_selesai',function(){
            var id=$(this).attr('data-selesai');
            $('#ModalSelesai').modal('show');
            $('[name="id_selesai"]').val(id);
});

$('#tabel-ir').on('click','.item_selesai',function(){
            var id=$(this).attr('data-selesai');
            $('#ModalSelesai').modal('show');
            $('[name="id_selesai"]').val(id);
});

        //Hapus Barang
        $('#btn_hapus').on('click',function(){
          $('#btn_hapus').prop("disabled",true);
            var id=$('#id_hapus').val();
            $.ajax({
            type : "POST",
            url  : "<?php echo base_url('invoice/hapus/')?>"+id,
            data : {id_hapus: id},
                    success: function(data){
                            $('#ModalHapus').modal('hide');
                            table_ketan.ajax.reload();
                            table_ir.ajax.reload();
                            table_katul.ajax.reload();
      table_katul.ajax.reload();
                            $('#btn_hapus').prop("disabled",false);
                    }
                });
                return false;
            });


          $('#btn_selesai').on('click',function(){
          $('#btn_selesai').prop("disabled",true);
            var id=$('#id_selesai').val();
            $.ajax({
            type : "POST",
            url  : "<?php echo base_url('invoice/selesai/')?>"+id,
            data : {id_selesai: id},
                    success: function(data){
                            $('#ModalSelesai').modal('hide');
                            table_ketan.ajax.reload();
                            table_ir.ajax.reload();
                            table_katul.ajax.reload();
      table_katul.ajax.reload();
                            $('#btn_selesai').prop("disabled",false);
                    }
                });
                return false;
            });


/*------------------------------PEMBAYARAN----------------------------*/

$('#tabel-ketan, #tabel-katul').on('click','.item_bayar',function(){
            $("#form-bayar")[0].reset();
            var id = $(this).attr('data');
            var tgl = $(this).attr('tanggal-invoice');
            var tot = $(this).attr('total-invoice');
            var plg = $(this).attr('pelanggan');
            var dibayar = $(this).attr('dibayar');
            var sisa = $(this).attr('sisa');

            $('#modal-input-bayar').modal('show');
            $('[name="id_bayar"]').val(id);
            $('[name="tanggal_invoice"]').val(tgl);
            $('[name="pelanggan"]').val(plg);
            $('[name="total_invoice"]').val(uang(tot));
            $('[name="sudah_dibayar"]').val(uang(dibayar));
            $('[name="sisa"]').val(uang(sisa));

            if (AutoNumeric.getAutoNumericElement('[name="bayar"]') === null) {
                  const autoNumericOptionsRp = {
                    allowDecimalPadding        : false, 
                    currencySymbol             : '',
                    currencySymbolPlacement    : 'p',
                    decimalCharacter           : ',',
                    digitGroupSeparator        : '.',
                    emptyInputBehavior         : 'focus',
                    maximumValue               : sisa
                };
                  mata = new AutoNumeric('[name="bayar"]', autoNumericOptionsRp);
                }
                else
                {
                  
                  AutoNumeric.set('[name="bayar"]','0');
                  mata.update({ maximumValue : sisa });
                }
});

$('#tabel-ir').on('click','.item_bayar',function(){
            $("#form-bayar")[0].reset();
            var id = $(this).attr('data');
            var tgl = $(this).attr('tanggal-invoice');
            var tot = $(this).attr('total-invoice');
            var plg = $(this).attr('pelanggan');
            var dibayar = $(this).attr('dibayar');
            var sisa = $(this).attr('sisa');

            $('#modal-input-bayar').modal('show');
            $('[name="id_bayar"]').val(id);
            $('[name="tanggal_invoice"]').val(tgl);
            $('[name="pelanggan"]').val(plg);
            $('[name="total_invoice"]').val(uang(tot));
            $('[name="sudah_dibayar"]').val(uang(dibayar));
            $('[name="sisa"]').val(uang(sisa));

            if (AutoNumeric.getAutoNumericElement('[name="bayar"]') === null) {
                  const autoNumericOptionsRp = {
                    allowDecimalPadding        : false, 
                    currencySymbol             : '',
                    currencySymbolPlacement    : 'p',
                    decimalCharacter           : ',',
                    digitGroupSeparator        : '.',
                    emptyInputBehavior         : 'focus',
                    maximumValue               : sisa
                };
                  mata = new AutoNumeric('[name="bayar"]', autoNumericOptionsRp);
                }
                else
                {
                  
                  AutoNumeric.set('[name="bayar"]','0');
                  mata.update({ maximumValue : sisa });
                }
});


$("#form-bayar").submit(function(e) {
e.preventDefault(); // avoid to execute the actual submit of the form.
var form = $(this);
var actionUrl = form.attr('action');
var method = form.attr('method');
$.ajax({
    type: method,
    url: actionUrl,
    data: form.serialize(), // serializes the form's elements.
    success: function(data)
    {
      console.log('Submit Berhasil !');
      table_ketan.ajax.reload();
      table_ir.ajax.reload();
      table_katul.ajax.reload();
    },
    error: function (data) {
      console.log('Submit Error !');
    },
});
$("#form-bayar")[0].reset();
$("#modal-input-bayar").modal('hide');
});

$('#tabel-ketan, #tabel-katul').on('click','.item_riwayat',function(){
            var id = $(this).attr('data');

            $("#printSection-history").load('<?php echo base_url('transaksi/invoice/riwayat-pembayaran');?>/'+id);
            $('#modal-riwayat-bayar').modal('show');

});

$('#tabel-ir').on('click','.item_riwayat',function(){
            var id = $(this).attr('data');

            $("#printSection-history").load('<?php echo base_url('transaksi/invoice/riwayat-pembayaran');?>/'+id);
            $('#modal-riwayat-bayar').modal('show');

});


/*------------------------------PEMBAYARAN----------------------------*/


/*------------------------------RETUR (IR)----------------------------*/
var anRetur = null;

// Tambah / Edit Retur
$('#tabel-ir').on('click','.item_retur',function(){
            var el = $(this);
            var total_tonase = parseFloat(el.attr('total-tonase')) || 0;
            var tonase_return = parseInt(el.attr('tonase-return')) || 0;

            $('#form-retur')[0].reset();
            $('#retur-error').hide().html('');
            $('#judul-retur').text(tonase_return > 0 ? 'Edit Retur' : 'Tambah Retur');
            $('#retur_id_invoice').val(el.attr('data'));
            $('#retur_tanggal').val(el.attr('tanggal-invoice'));
            $('#retur_pelanggan').val(el.attr('pelanggan'));
            $('#retur_no_truk').val(el.attr('no-truk'));
            $('#retur_total_tonase').val(uang(Math.floor(total_tonase)));

            var opsiRetur = {
                allowDecimalPadding     : false,
                decimalPlaces           : 0,
                currencySymbol          : '',
                decimalCharacter        : ',',
                digitGroupSeparator     : '.',
                emptyInputBehavior      : 'focus',
                minimumValue            : '0',
                maximumValue            : String(Math.floor(total_tonase))
            };
            if (anRetur === null) {
                anRetur = new AutoNumeric('#retur_tonase', opsiRetur);
            } else {
                anRetur.update(opsiRetur);
            }
            if (tonase_return > 0) { anRetur.set(tonase_return); } else { anRetur.clear(); }

            $('#modal-retur').modal('show');
});

$('#form-retur').submit(function(e){
    e.preventDefault();
    var form = $(this);
    var tonase = anRetur ? anRetur.getNumber() : 0;
    if (!tonase || tonase <= 0) {
        $('#retur-error').html('Tonase retur harus lebih dari 0.').show();
        return false;
    }
    $('#btn_simpan_retur').prop('disabled', true);
    $.ajax({
        type: form.attr('method'),
        url: form.attr('action'),
        data: { id_invoice: $('#retur_id_invoice').val(), tonase_return: tonase },
        dataType: 'json',
        success: function(res){
            if (res.status) {
                $('#modal-retur').modal('hide');
                table_ir.ajax.reload(null, false);
            } else {
                $('#retur-error').html(res.message).show();
            }
        },
        error: function(xhr){
            var msg = (xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : 'Gagal menyimpan retur.';
            $('#retur-error').html(msg).show();
        },
        complete: function(){
            $('#btn_simpan_retur').prop('disabled', false);
        }
    });
});

// Hapus Retur
$('#tabel-ir').on('click','.item_hapus_retur',function(){
            var el = $(this);
            $('#hapus_retur_id').val(el.attr('data'));
            $('#hapus_retur_tonase').text(uang(el.attr('tonase-return')));
            $('#hapus_retur_info').text(el.attr('tanggal-invoice') + ' - ' + el.attr('no-truk'));
            $('#ModalHapusRetur').modal('show');
});

$('#btn_hapus_retur').on('click',function(){
    $('#btn_hapus_retur').prop('disabled', true);
    $.ajax({
        type: 'POST',
        url: '<?php echo base_url('invoice/hapus_retur');?>',
        data: { id_invoice: $('#hapus_retur_id').val() },
        dataType: 'json',
        success: function(res){
            $('#ModalHapusRetur').modal('hide');
            if (!res.status) { alert(res.message); }
            table_ir.ajax.reload(null, false);
        },
        error: function(){
            alert('Gagal menghapus retur.');
        },
        complete: function(){
            $('#btn_hapus_retur').prop('disabled', false);
        }
    });
});
/*------------------------------RETUR (IR)----------------------------*/

});



</script>
  <section class="content-header">
      <h1>
        Invoice
      </h1>
      <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-refresh"></i> Transaksi</a></li>
        <li class="active">Invoice</li>
      </ol>
    </section>



    <section class="content">

<a class="btn btn-app" href="#" data-toggle="modal" data-target="#modal-buat">
<i class="fa fa-plus"></i> Tambah Invoice
</a>

<!----------------------------------MODAL BAYAR------------------------------------------------------------>
<div class="modal fade" id="modal-input-bayar">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">Form Input Pembayaran</h4>
</div>
<form action="<?php echo base_url('invoice/simpan_pembayaran') ;?>" method="post" id="form-bayar" autocomplete="off">
<div class="modal-body">

      <input type="hidden" name="id_bayar">

      <div class="row">
        <div class="col-md-6">
        <div id="tagNama" class="form-group">
            <label class="control-label" for="inputError"><i id="iconNama"></i> Tanggal Invoice</label>
            <input type="text" name="tanggal_invoice"  class="form-control" placeholder="Tanggal Invoice" readonly>
            <span class="help-block" id="pesanNama"></span>
        </div>
        </div>

        <div class="col-md-6">
        <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Pelanggan</label>
          <input type="text" name="pelanggan" class="form-control" placeholder="Pelanggan" readonly>
          <span class="help-block" id="pesanNama"></span>
        </div>
        </div>
        <div class="col-md-6">
            <div id="tagNama" class="form-group">
              <label class="control-label" for="inputError"><i id="iconNama"></i> Total Invoice</label>
              <input type="text" name="total_invoice" class="form-control" placeholder="Total" readonly>
              <span class="help-block" id="pesanNama"></span>
            </div>
        </div>

        <div class="col-md-6">  
          <div id="tagNama" class="form-group">
              <label class="control-label" for="inputError"><i id="iconNama"></i> Sudah Bayar</label>
              <input type="text" name="sudah_dibayar" class="form-control" placeholder="Sudah Bayar" readonly>
              <span class="help-block" id="pesanNama"></span>
            </div>
        </div>
      </div>

      
      <div id="tagNama" class="form-group">
              <label class="control-label" for="inputError"><i id="iconNama"></i> Sisa</label>
              <input type="text" name="sisa" class="form-control" placeholder="Sisa" readonly>
              <span class="help-block" id="pesanNama"></span>
            </div>

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Pilih Tanggal Pembayaran</label>
          <input type="text" name="tanggal" id="datepicker" class="form-control" placeholder="Tanggal" required
          data-date-format="dd-mm-yyyy" value="<?php echo date("d-m-Y");?>" data-date-end-date="0d">
          <span class="help-block" id="pesanNama"></span>
      </div>

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Nominal Bayar</label>
          <input type="text" name="bayar"  class="form-control" placeholder="Bayar" required>
          <span class="help-block" id="pesanNama"></span>
      </div>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
</div>
</form>
</div>
</div>
</div>
<!----------------------------------MODAL BAYAR------------------------------------------------------------>


<!----------------------------------MODAL RIWAYAT---------------------------------------------------------->
<div class="modal fade" id="modal-riwayat-bayar">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">Riwayat Pembayaran</h4>
</div>
<div class="modal-body">

<div id="printSection-history">
</div>

</div>


</div>
</div>
</div>
<!----------------------------------MODAL RIWAYAT---------------------------------------------------------->


<!--MODAL BUAT-->
<div class="modal fade" id="modal-buat">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title">Form Input Invoice</h4>
</div>
<form action="<?php echo base_url('invoice/buat') ;?>" method="post" id="form-buat" autocomplete="off">
<div class="modal-body">

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Tanggal Invoice</label>
          <input type="text" name="tanggal" id="tgl" class="form-control" placeholder="Tanggal" required
          data-date-format="dd-mm-yyyy" value="<?php echo date("d-m-Y");?>" data-date-end-date="0d">
          <span class="help-block" id="pesanNama"></span>
      </div>

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Pilih Kategori</label>
          <select name="id_kategori"  class="form-control" id="id_kategori" required>
            <option value="">Pilih Kategori*</option>
            <?php
            foreach ($kategori as $k) {
              echo '<option value="'.$k->id.'">'.$k->nama_kategori.'</option>';
            }

            ?>
          </select>
          <span class="help-block" id="pesanNama"></span>
      </div>

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> Pilih Pelanggan</label>
          <select name="id_pelanggan"  class="form-control select2" style="width: 100%;" id="id_pelanggan" required>
          </select>
          <span class="help-block" id="pesanNama"></span>
      </div>

      <div id="tagNama" class="form-group">
          <label class="control-label" for="inputError"><i id="iconNama"></i> No Truk</label>
          <input type="text" name="no_polisi" id="no_polisi" class="form-control" placeholder="No Truk" required>
          <span class="help-block" id="pesanNama"></span>
      </div>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
</div>
</form>
</div>
</div>
</div>
<!--MODAL BUAT-->





<div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-info"></i> Catatan</h4>
               Hanya Invoice yang ber status <strong>Selesai</strong> yang bisa dicetak. 
</div>

<div class="box">
   <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <?php
              $counter = 0;
              foreach ($kategori as $k) {
                if ($counter == 0) {
                  echo '<li class="active"><a href="#tab_'.$k->id.'" data-toggle="tab">'.$k->nama_kategori.'</a></li>';
                }
                else
                {
                  echo '<li><a href="#tab_'.$k->id.'" data-toggle="tab">'.$k->nama_kategori.'</a></li>';
                }
                $counter++;
              } 
              ?>
            </ul>
            <div class="tab-content">
              <?php
              $counter = 0;
              foreach ($kategori as $k) {
                  $isActive = ($counter == 0) ? 'active' : '';
                  echo '<div class="tab-pane '.$isActive.'" id="tab_'.$k->id.'">';
              ?>
              <table id="tabel-<?php echo strtolower($k->nama_kategori);  ?>" class="table table-bordered table-striped">
                <thead>
                <?php if (strtoupper($k->nama_kategori) == 'IR') { ?>
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Pelanggan</th>
                  <th>No Truk</th>
                  <th>Tonase</th>
                  <th>Retur</th>
                  <th>Tonase Akhir</th>
                  <th>Status</th>
                  <th>Piutang</th>
                  <th>Aksi</th>
                </tr>
                <?php } else { ?>
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Pelanggan</th>
                  <th>No Truk</th>
                  <th>KBK Angkut</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Pembayaran</th>
                  <th>Piutang</th>
                  <th>Aksi</th>
                </tr>
                <?php } ?>
                </thead>
              </table>
              <?php
                  echo '</div>';
                  $counter++;
                
              }
              ?>
            </div>
</div>


<!--MODAL HAPUS-->
<div class="modal modal-danger fade" id="ModalHapus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
<div class="modal-dialog" role="document">
  <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
          <h4 class="modal-title" id="myModalLabel">Konfirmasi Hapus Invoice</h4>
      </div>
      <form class="form-horizontal">
      <div class="modal-body">
                              
              <input type="hidden" name="id_hapus" id="id_hapus" value="">
              <div class="alert alert-default"><p>Apakah Anda yakin mau menghapus Invoice <span id="nama"></span> ?</p></div>
                            
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button class="btn_hapus btn btn-danger" id="btn_hapus">Hapus</button>
      </div>
      </form>
  </div>
</div>
</div>
<!--END MODAL HAPUS-->


<!--MODAL SELESAI-->
<div class="modal modal-info fade" id="ModalSelesai" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">X</span></button>
            <h4 class="modal-title" id="myModalLabel">Konfirmasi Penyelesaian</h4>
        </div>
        <form class="form-horizontal">
        <div class="modal-body">
                                
                <input type="hidden" name="id_selesai" id="id_selesai" value="">
                <div class="alert alert-default"><p>Selesaikan Invoice Ini ?</p></div>
                              
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
            <button class="btn_hapus btn btn-info" id="btn_selesai">Selesai</button>
        </div>
        </form>
    </div>
  </div>
</div>
<!--END MODAL SELESAI-->


<!----------------------------------MODAL RETUR (IR)------------------------------------------------------->
<div class="modal fade" id="modal-retur">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span></button>
<h4 class="modal-title" id="judul-retur">Tambah Retur</h4>
</div>
<form action="<?php echo base_url('invoice/simpan_retur') ;?>" method="post" id="form-retur" autocomplete="off">
<div class="modal-body">

      <input type="hidden" name="id_invoice" id="retur_id_invoice">

      <div class="alert alert-danger" id="retur-error" style="display:none;"></div>

      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label">Tanggal Invoice</label>
            <input type="text" id="retur_tanggal" class="form-control" readonly>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label">Pelanggan</label>
            <input type="text" id="retur_pelanggan" class="form-control" readonly>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label">No Truk</label>
            <input type="text" id="retur_no_truk" class="form-control" readonly>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label class="control-label">Total Tonase</label>
            <input type="text" id="retur_total_tonase" class="form-control" readonly>
          </div>
        </div>
      </div>

      <div class="form-group">
          <label class="control-label">Tonase Retur</label>
          <input type="text" name="tonase_return" id="retur_tonase" class="form-control" placeholder="Jumlah tonase yang diretur" required>
          <span class="help-block">Maksimal sebesar Total Tonase invoice.</span>
      </div>

</div>
<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>
<button type="submit" class="btn btn-primary" id="btn_simpan_retur"><i class="fa fa-save"></i> Simpan</button>
</div>
</form>
</div>
</div>
</div>
<!----------------------------------MODAL RETUR (IR)------------------------------------------------------->


<!--MODAL HAPUS RETUR-->
<div class="modal modal-danger fade" id="ModalHapusRetur" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
  <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">x</span></button>
          <h4 class="modal-title">Konfirmasi Hapus Retur</h4>
      </div>
      <div class="modal-body">
          <input type="hidden" id="hapus_retur_id" value="">
          <div class="alert alert-default"><p>Hapus retur <strong id="hapus_retur_tonase"></strong> pada invoice <strong id="hapus_retur_info"></strong> ?</p></div>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="button" class="btn btn-danger" id="btn_hapus_retur">Hapus</button>
      </div>
  </div>
</div>
</div>
<!--END MODAL HAPUS RETUR-->

</div>
</section>